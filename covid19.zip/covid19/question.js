
var questions = [{
    "question": "Do you have cough ?/ Avez-vous de la toux ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },  {
    "question": "Do you have a runny nose ?/ Avez-vous le rhume ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Are you having Diarrhea ?/ Avez-vous la diarrhee ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Do you have a loss of smell and taste ?/ Avez-vous une perte de l'odorat et du gout ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Do you have headache ?/ Avez-vous des maux de tete ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Are you experiencing MYALGIA or body aches ?/ Avez-vous des courbatures et douleurs musculaires ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Are you having sore throat ?/ Avez-vous des maux de gorge ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Are you having fever(temperature 37.8 and above) ?/ Avez-vous de la fievre > 37.8 ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Are you having difficulty breathing ?/ Avez-vous des difficultes respiratoires ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Are you experiencing fatigue ?/ Avez-vous des sensations de fatigue ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Have you traveled recently during the past 14 days ?/ Avez-vous ete a l'etranger dans les deux dernieres semaines ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Do you have a travel history to COVID-19 INFECTED AREA ?/ Avez-vous ete en voyage dans un pays concerne par la pandemie a COVID-19 ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
    "question": "Do you have a direct contact or taking care of a positive COVID-19 ?/ Avez-vous ete en contact avec un cas confirme de COVID-19 ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 }
];
