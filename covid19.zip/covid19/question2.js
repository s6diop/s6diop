
var questions = [{
    "question": "Are you over the age of 60 ?/ Avez-vous un age superieur a 60 ans ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
   "question": "Do you have high blood pressure ?/ Avez-vous l'hypertension arterielle ?",
   "option1": "Yes",
   "option2": "No",
   "answer": "1"
},{
   "question": "Do you have cancer ?/ Avez-vous un cancer ?",
   "option1": "Yes",
   "option2": "No",
   "answer": "1"
},{
   "question": "Do you have heart disease ?/ Avez-vous une maladie cardiaque ?",
   "option1": "Yes",
   "option2": "No",
   "answer": "1"
},{
   "question": "Do you have lung disease ?/ Avez-vous une maladie pulmonaire ?",
   "option1": "Yes",
   "option2": "No",
   "answer": "1"
},{
    "question": "Do you have kidney disease ?/ Avez-vous une maladie renale ?",
    "option1": "Yes",
    "option2": "No",
    "answer": "1"
 },{
   "question": "Do you have diabetes ?/ Avez-vous le diabete ?",
   "option1": "Yes",
   "option2": "No",
   "answer": "1"
},
];
